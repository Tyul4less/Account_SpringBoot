package net.plang.HoWooAccount.hr.salary;

public class sal {

}
