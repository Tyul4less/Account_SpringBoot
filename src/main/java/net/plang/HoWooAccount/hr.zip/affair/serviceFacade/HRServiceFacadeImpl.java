package net.plang.HoWooAccount.hr.affair.serviceFacade;

import java.util.ArrayList;

import lombok.Setter;

import net.plang.HoWooAccount.hr.affair.applicationservice.HrApplicationService;
import net.plang.HoWooAccount.hr.affair.dao.EmployeeDAO;
import net.plang.HoWooAccount.hr.affair.to.DepartmentBean;
import net.plang.HoWooAccount.hr.affair.to.EmployeeBean;
import net.plang.HoWooAccount.system.common.exception.DataAccessException;

@Setter
public class HRServiceFacadeImpl implements HRServiceFacade {

    private EmployeeDAO employeeDAO;
    private HrApplicationService hrApplicationService;


    @Override
    public EmployeeBean findEmployee(String empCode) {

        EmployeeBean employeeBean = null;
        try {
            employeeBean = hrApplicationService.findEmployee(empCode);;
        } catch (DataAccessException e) {
            throw e;
        }
        return employeeBean;
    }

    @Override
    public ArrayList<EmployeeBean> findEmployeeList(String deptCode) {

        ArrayList<EmployeeBean> empList = null;
        try {
            empList = hrApplicationService.findEmployeeList(deptCode);
        } catch (DataAccessException e) {
            throw e;
        }
        return empList;
    }
    
    @Override
    public ArrayList<EmployeeBean> findEmployeeList() {

        ArrayList<EmployeeBean> empList = null;
        try {
            empList = employeeDAO.selectEmployeeList();
        } catch (DataAccessException e) {
            throw e;
        }
        return empList;
    }

    @Override
    public void batchEmployeeInfo(EmployeeBean employeeBean) {

        try {
            hrApplicationService.batchEmployeeInfo(employeeBean);
        } catch (DataAccessException e) {
            throw e;
        }
    }


    @Override
    public void batchEmployee(ArrayList<EmployeeBean> empList) {

        try {
            hrApplicationService.batchEmployee(empList);
            for (int a = 0; a < empList.size(); a++) {
            }
        } catch (DataAccessException e) {
            throw e;
        }
    }

    @Override
    public void registerEmployee(EmployeeBean employeeBean) {

        try {
            hrApplicationService.registerEmployee(employeeBean);
        } catch (DataAccessException e) {
            throw e;
        }
    }

	@Override
	public void removeEmployee(EmployeeBean employeeBean) {

	        try {
	            hrApplicationService.removeEmployee(employeeBean);
	        } catch (DataAccessException e) {
	            throw e;
	        }
	}

	@Override
	public ArrayList<DepartmentBean> findDeptList() {

        ArrayList<DepartmentBean> deptList=null;
        try {
        	deptList=hrApplicationService.findDeptList();
        } catch (DataAccessException e) {
            throw e;
        }
        return deptList;
	}

	@Override
	public ArrayList<DepartmentBean> findDetailDeptList(String workplaceCode) {

        ArrayList<DepartmentBean> detailDeptList=null;
        try {
        	detailDeptList=hrApplicationService.findDetailDeptList(workplaceCode);
        } catch (DataAccessException e) {
            throw e;
        }
        return detailDeptList;
	}

	@Override
	public ArrayList<DepartmentBean> findDeptList2() {

        ArrayList<DepartmentBean> deptList=null;
        try {
            deptList=hrApplicationService.findDeptList2();
        } catch (DataAccessException e) {
            throw e;
        }
        return deptList;
	}

}
