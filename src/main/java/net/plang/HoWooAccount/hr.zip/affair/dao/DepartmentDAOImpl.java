package net.plang.HoWooAccount.hr.affair.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import lombok.Setter;

import net.plang.HoWooAccount.hr.affair.to.DepartmentBean;
import net.plang.HoWooAccount.system.common.exception.DataAccessException;

@Setter
public class DepartmentDAOImpl implements DepartmentDAO{

	private DataSourceTransactionManager dataSourceTransactionManager = DataSourceTransactionManager.getInstance();
    // application이 팩토리를 상관하지않고 명명된 logger를 리턴함. clazz : log이름이 파생되는 클래스변수
    // public static Log getLog(Class clazz)



	@Override
	public ArrayList<DepartmentBean> selectDeptList() {
		// TODO Auto-generated method stub
	        Connection con = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        ArrayList<DepartmentBean> deptList = new ArrayList<DepartmentBean>();
	        try {
	            StringBuffer query = new StringBuffer();
	            query.append(" select distinct workplace_code, ");
	            query.append(" workplace_name ");
	            query.append(" from department ");
	            con = dataSourceTransactionManager.getConnection();
	            pstmt = con.prepareStatement(query.toString());
	            rs = pstmt.executeQuery();
	            while (rs.next()) {
	                DepartmentBean deptBean = new DepartmentBean();
	                deptBean.setWorkplaceCode(rs.getString("WORKPLACE_CODE"));
	                deptBean.setWorkplaceName(rs.getString("WORKPLACE_NAME"));	               
	                deptList.add(deptBean);
	            }
	            return deptList;
	        } catch (Exception sqle) {
	            throw new DataAccessException(sqle.getMessage());
	        } finally {
	            dataSourceTransactionManager.close(pstmt, rs);
	        }
	}

	@Override
	public ArrayList<DepartmentBean> selectDetailDeptList(String workplaceCode) {
		// TODO Auto-generated method stub
	        Connection con = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs = null;
	        ArrayList<DepartmentBean> detailDeptList = new ArrayList<DepartmentBean>();
	        try {
	            StringBuffer query = new StringBuffer();
	            query.append(" select workplace_code, ");
	            query.append(" workplace_name, ");
	            query.append(" dept_code, ");
	            query.append(" dept_name ");
	            query.append(" from department ");
	            query.append(" where workplace_code=? ");
	            query.append(" and (dept_end_date>sysdate ");
	            query.append(" or dept_end_date is null) ");
	            con = dataSourceTransactionManager.getConnection();
	            pstmt = con.prepareStatement(query.toString());
	            pstmt.setString(1, workplaceCode);
	            rs = pstmt.executeQuery();
	            while (rs.next()) {
	                DepartmentBean deptBean = new DepartmentBean();
	                deptBean.setWorkplaceCode(rs.getString("WORKPLACE_CODE"));
	                deptBean.setWorkplaceName(rs.getString("WORKPLACE_NAME"));
	                deptBean.setDeptCode(rs.getString("DEPT_CODE"));
	                deptBean.setDeptName(rs.getString("DEPT_NAME"));
	                detailDeptList.add(deptBean);
	            }
	            return detailDeptList;
	        } catch (Exception sqle) {
	            throw new DataAccessException(sqle.getMessage());

	        } finally {
	            dataSourceTransactionManager.close(pstmt, rs);
	        }
	}

	@Override
	public ArrayList<DepartmentBean> selectDeptList2() {
		// TODO Auto-generated method stub
			        Connection con = null;
			        PreparedStatement pstmt = null;
			        ResultSet rs = null;
			        ArrayList<DepartmentBean> deptList = new ArrayList<DepartmentBean>();
			        try {
			            StringBuffer query = new StringBuffer();
			            query.append(" select dept_code, ");
			            query.append(" dept_name ");
			            query.append(" from department ");
			            con = dataSourceTransactionManager.getConnection();
			            pstmt = con.prepareStatement(query.toString());
			            rs = pstmt.executeQuery();
			            while (rs.next()) {
			                DepartmentBean deptBean = new DepartmentBean();
			                deptBean.setDeptCode(rs.getString("DEPT_CODE"));
			                deptBean.setDeptName(rs.getString("DEPT_NAME"));	               
			                deptList.add(deptBean);
			            }
			            return deptList;
			        } catch (Exception sqle) {
			            // log4j : log for java. 자바프로그램의 실행과정을 기록하는 도구
			            throw new DataAccessException(sqle.getMessage());

			        } finally {
			            dataSourceTransactionManager.close(pstmt, rs);
			        }
	}
}
