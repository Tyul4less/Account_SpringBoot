package net.plang.HoWooAccount.hr.affair.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.Setter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.plang.HoWooAccount.hr.affair.serviceFacade.HRServiceFacade;
import net.plang.HoWooAccount.hr.affair.serviceFacade.HRServiceFacadeImpl;
import net.plang.HoWooAccount.hr.affair.to.EmployeeBean;
import net.plang.HoWooAccount.system.common.exception.DataAccessException;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;

@Setter
public class EmployeeModifyController {

    private HRServiceFacade hrServiceFacade;

    ModelAndView mav;
    ModelMap map = new ModelMap();

    public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) {

        JSONObject json = new JSONObject();
        PrintWriter out = null;
        ArrayList<EmployeeBean> empList = new ArrayList<EmployeeBean>();
        try {

            JSONObject jsonObject = JSONObject.fromObject(request.getParameter("batchList"));
            JSONArray jsonEmployeeArray = jsonObject.getJSONArray("batchList");


            for (Object obj : jsonEmployeeArray) {

                EmployeeBean employeeBean = (EmployeeBean) JSONObject.toBean((JSONObject) obj, EmployeeBean.class);
                empList.add(employeeBean);
            }
            out = response.getWriter();
            hrServiceFacade.batchEmployee(empList);

            map.put("errorCode", 1);
            map.put("errorMsg", "성공");
            mav = new ModelAndView("jsonView",map);
        } catch (IOException e) {
            map.put("errorCode", -1);
            map.put("errorMsg", "실패");

        }

        return mav;
    }


}
