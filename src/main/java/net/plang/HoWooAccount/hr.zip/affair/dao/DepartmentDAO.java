package net.plang.HoWooAccount.hr.affair.dao;

import java.util.ArrayList;

import net.plang.HoWooAccount.hr.affair.to.DepartmentBean;

public interface DepartmentDAO {
	
	public ArrayList<DepartmentBean> selectDeptList();
	
	public ArrayList<DepartmentBean> selectDeptList2();
	
	public ArrayList<DepartmentBean> selectDetailDeptList(String workplaceCode);

}
