package net.plang.HoWooAccount.hr.affair.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import net.plang.HoWooAccount.hr.affair.serviceFacade.HRServiceFacade;
import net.plang.HoWooAccount.hr.affair.to.DepartmentBean;
import net.plang.HoWooAccount.hr.affair.to.EmployeeBean;
import net.plang.HoWooAccount.system.common.exception.DataAccessException;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import net.sf.json.JSONObject;

public class HRController extends MultiActionController {

    private HRServiceFacade hrServiceFacade;

    public void setHRServiceFacade (HRServiceFacade hrServiceFacade) {
        this.hrServiceFacade = hrServiceFacade;
    }

    ModelAndView mav = null;
    ModelMap map = new ModelMap();

/*    @Bean
    public CharacterEncodingFilter characterEncodingFilter() {
        CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
        characterEncodingFilter.setEncoding("UTF-8");
        characterEncodingFilter.setForceEncoding(true);
        return characterEncodingFilter;
    }*/

    public ModelAndView findEmployeeList(HttpServletRequest request, HttpServletResponse response) {

        JSONObject json = new JSONObject();
        PrintWriter out = null;
        try {
            String deptCode = request.getParameter("deptCode");
            ArrayList<EmployeeBean> empList = hrServiceFacade.findEmployeeList(deptCode);
            out = response.getWriter();
            json.put("empList", empList);
            json.put("errorCode", 1);
            json.put("errorMsg", "성공");
        } catch (IOException e) {
            json.put("errorCode", -1);
            json.put("errorMsg", "실패");
            e.printStackTrace();
        } catch (DataAccessException e) {
            json.put("errorCode", -2);
            //json.put("errorMes",e.getMessage());
            json.put("errorMes", "DB오류");
            e.printStackTrace();
        }
        out.println(json);
        out.close();
        return null;

    }

    public ModelAndView findEmployeeList1(HttpServletRequest request, HttpServletResponse response) {

        JSONObject json = new JSONObject();
        PrintWriter out = null;
        try {
            // String deptCode = request.getParameter("deptCode");
            ArrayList<EmployeeBean> empList = hrServiceFacade.findEmployeeList();
            out = response.getWriter();
            json.put("empList", empList);
            json.put("errorCode", 1);
            json.put("errorMsg", "성공");
        } catch (IOException e) {
            json.put("errorCode", -1);
            json.put("errorMsg", "실패");
            e.printStackTrace();
        } catch (DataAccessException e) {
            json.put("errorCode", -2);
            //json.put("errorMes",e.getMessage());
            json.put("errorMes", "DB오류");
            e.printStackTrace();
        }
        out.println(json);
        out.close();
        return null;
    }

    //@RequestMapping(value = "/add", produces = "application/text; charset=utf8")
    public ModelAndView findEmployee(HttpServletRequest request, HttpServletResponse response) {

        try {
            String empCode = request.getParameter("empCode");
            EmployeeBean employeeBean = hrServiceFacade.findEmployee(empCode);

/*            response.setHeader("Content-Type", "application/xml");
            response.setContentType("text/xml;charset=UTF-8");*/
            response.setCharacterEncoding("utf-8");
            map.put("employeeInfo", employeeBean);
            map.put("errorCode", 1);
            map.put("errorMsg", "성공");
        } catch (Exception e) {
            map.put("errorCode", -1);
            map.put("errorMsg", "실패");
            e.printStackTrace();
        }
        mav = new ModelAndView("jsonView", map);
        return mav;
    }


    public ModelAndView batchEmpInfo(HttpServletRequest request, HttpServletResponse response) {
        JSONObject json = new JSONObject();
        PrintWriter out = null;
        try {
            out = response.getWriter();
            JSONObject jsonObject = JSONObject.fromObject(request.getParameter("sendData"));
            //String image = request.getParameter("image");
            EmployeeBean employeeBean = (EmployeeBean)JSONObject.toBean(jsonObject,EmployeeBean.class);

            hrServiceFacade.batchEmployeeInfo(employeeBean);

            json.put("errorCode", 1);
            json.put("errorMsg", "성공");
        } catch (IOException e) {
            json.put("errorCode", -1);
            json.put("errorMsg", "실패");
            e.printStackTrace();
        } catch (DataAccessException e) {
            json.put("errorCode", -2);
            //json.put("errorMsg", e.getMessage());
            json.put("errorMsg", "DB오류");
            e.printStackTrace();
        }
        out.println(json);
        out.close();
        return null;
    }

    public ModelAndView EmptyEmpBean(HttpServletRequest request, HttpServletResponse response) {

        JSONObject json = new JSONObject();
        PrintWriter out = null;
        try {
            out = response.getWriter();
            json.put("EmptyEmpBean", new EmployeeBean());
            json.put("errorCode", 1);
            json.put("errorMsg", "성공");
        } catch (IOException e) {
            json.put("errorCode", -1);
            json.put("errorMsg", "실패");
            e.printStackTrace();
        } catch (DataAccessException e) {
            json.put("errorCode", -2);
            //json.put("errorMsg", e.getMessage());
            json.put("errorMsg", "DB오류");
            e.printStackTrace();
        }
        out.println(json);
        out.close();
        return null;
    }

    public ModelAndView batchEmp(HttpServletRequest request, HttpServletResponse response) {

        JSONObject json = new JSONObject();
        PrintWriter out = null;
        try {
            out = response.getWriter();
            JSONObject jsonObject = JSONObject.fromObject(request.getParameter("JoinEmployee"));

            EmployeeBean employeeBean = (EmployeeBean) JSONObject.toBean(jsonObject, EmployeeBean.class);

            hrServiceFacade.registerEmployee(employeeBean);

            json.put("errorCode", 1);
            json.put("errorMsg", "성공");
        } catch (IOException e) {
            json.put("errorCode", -1);
            json.put("errorMsg", "실패");
            e.printStackTrace();
        } catch (DataAccessException e) {
            json.put("errorCode", -2);
            // json.put("errorMsg", e.getMessage());
            json.put("errorMsg", "DB오류");
            e.printStackTrace();
        }
        out.println(json);
        out.close();
        return null;
    }


    public ModelAndView deleteEmployee(HttpServletRequest request, HttpServletResponse response) {

        JSONObject json = new JSONObject();
        PrintWriter out = null;
        try {
            out = response.getWriter();
            String empCode = request.getParameter("empCode");
            EmployeeBean employeeBean = new EmployeeBean();
            employeeBean.setEmpCode(empCode);

            hrServiceFacade.removeEmployee(employeeBean);
            json.put("errorCode", 1);
            json.put("errorMsg", "성공");
        } catch (IOException e) {
            json.put("errorCode", -1);
            json.put("errorMsg", "실패");
            e.printStackTrace();
        } catch (DataAccessException e) {
            json.put("errorCode", -2);
            // json.put("errorMsg", e.getMessage());
            json.put("errorMsg", "DB오류");
            e.printStackTrace();
        }
        out.println(json);
        out.close();
        return null;
    }

    public ModelAndView findDeptList(HttpServletRequest request, HttpServletResponse response) {

        JSONObject json = new JSONObject();
        PrintWriter out = null;
        try {
            ArrayList<DepartmentBean> deptList = hrServiceFacade.findDeptList();
            out = response.getWriter();
            json.put("deptList", deptList);
            json.put("errorCode", 1);
            json.put("errorMsg", "성공");
        } catch (IOException e) {
            json.put("errorCode", -1);
            json.put("errorMsg", "실패");
            e.printStackTrace();
        } catch (DataAccessException e) {
            json.put("errorCode", -2);
            //json.put("errorMes",e.getMessage());
            json.put("errorMes", "DB오류");
            e.printStackTrace();
        }
        out.println(json);
        out.close();
        return null;
    }

    public ModelAndView findDetailDeptList(HttpServletRequest request, HttpServletResponse response) {

        JSONObject json = new JSONObject();
        PrintWriter out = null;
        try {
            String workplaceCode = request.getParameter("workplaceCode");
            ArrayList<DepartmentBean> detailDeptList = hrServiceFacade.findDetailDeptList(workplaceCode);
            out = response.getWriter();
            json.put("detailDeptList", detailDeptList);
            json.put("errorCode", 1);
            json.put("errorMsg", "성공");
        } catch (IOException e) {
            json.put("errorCode", -1);
            json.put("errorMsg", "실패");
            e.printStackTrace();
        } catch (DataAccessException e) {
            json.put("errorCode", -2);
            //json.put("errorMes",e.getMessage());
            json.put("errorMes", "DB오류");
            e.printStackTrace();
        }
        out.println(json);
        out.close();
        return null;
    }

    public ModelAndView findDeptList2(HttpServletRequest request, HttpServletResponse response) {

        JSONObject json = new JSONObject();
        PrintWriter out = null;
        try {
            ArrayList<DepartmentBean> deptList = hrServiceFacade.findDeptList2();
            out = response.getWriter();
            json.put("deptList", deptList);
            json.put("errorCode", 1);
            json.put("errorMsg", "성공");
        } catch (IOException e) {
            json.put("errorCode", -1);
            json.put("errorMsg", "실패");
            e.printStackTrace();
        } catch (DataAccessException e) {
            json.put("errorCode", -2);
            //json.put("errorMes",e.getMessage());
            json.put("errorMes", "DB오류");
            e.printStackTrace();
        }
        out.println(json);
        out.close();
        return null;
    }
}
