package net.plang.HoWooAccount.hr.affair.applicationservice;

import java.util.ArrayList;

import lombok.Setter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import net.plang.HoWooAccount.hr.affair.dao.DepartmentDAO;
import net.plang.HoWooAccount.hr.affair.dao.DepartmentDAOImpl;
import net.plang.HoWooAccount.hr.affair.dao.EmployeeDAO;
import net.plang.HoWooAccount.hr.affair.dao.EmployeeDAOImpl;
import net.plang.HoWooAccount.hr.affair.to.DepartmentBean;
import net.plang.HoWooAccount.hr.affair.to.EmployeeBean;
import net.plang.HoWooAccount.system.base.dao.DetailCodeDAO;
import net.plang.HoWooAccount.system.base.dao.DetailCodeDAOImpl;
import net.plang.HoWooAccount.system.base.to.DetailCodeBean;
import net.plang.HoWooAccount.system.common.exception.DataAccessException;

@Setter
public class HrApplicationServiceImpl implements HrApplicationService {

    private EmployeeDAO employeeDAO;
    private DetailCodeDAO detailCodeDAO;
    private DepartmentDAO departmentDAO;


    @Override
    public ArrayList<EmployeeBean> findEmployeeList(String deptCode) {

        ArrayList<EmployeeBean> empList = null;
        try {
            empList = employeeDAO.selectEmployeeList(deptCode);
        } catch (DataAccessException e) {
            throw e;
        }
        return empList;
    }

    @Override
    public EmployeeBean findEmployee(String empCode) {

        EmployeeBean employeeBean = null;
        try {
            employeeBean = employeeDAO.selectEmployee(empCode);
        } catch (DataAccessException e) {
            throw e;
        }
        return employeeBean;
    }

    @Override
    public void batchEmployeeInfo(EmployeeBean employeeBean) {

        try {
            employeeDAO.updateEmployeeInfo(employeeBean);
        } catch (DataAccessException e) {
            throw e;
        }
    }

    @Override
    public void batchEmployee(ArrayList<EmployeeBean> empList) {

        try {
            for (EmployeeBean employBean : empList) {
                String empStatus = employBean.getStatus();
                switch (empStatus) {
                    case "update":
                        modifyEmployee(employBean);
                        break;
                    case "delete":
                        removeEmployee(employBean);
                        break;
                }
            }
        } catch (DataAccessException e) {
            throw e;
        }
    }

    private void modifyEmployee(EmployeeBean employeeBean) {

        try {
            employeeDAO.updateEmployee(employeeBean);
            String empCode = employeeBean.getEmpCode();
            String empName = employeeBean.getEmpName();
            DetailCodeBean detailCodeBean = new DetailCodeBean();
            detailCodeBean.setDivisionCodeNo("HR-02");
            detailCodeBean.setDetailCode(empCode);
            detailCodeBean.setDetailCodeName(empName);
            detailCodeDAO.updateDetailCode(detailCodeBean);
        } catch (DataAccessException e) {
            throw e;
        }
    }

    public void removeEmployee(EmployeeBean employBean) {

        try {
            employeeDAO.deleteEmployee(employBean.getEmpCode());
            detailCodeDAO.deleteDetailCode(employBean.getEmpCode());

        } catch (DataAccessException e) {
            throw e;

        }
    }

    @Override
    public void registerEmployee(EmployeeBean employeeBean) {

        try {
            employeeDAO.insertEmployee(employeeBean);
            String empCode = employeeBean.getEmpCode();
            String empName = employeeBean.getEmpName();
            DetailCodeBean detailCodeBean = new DetailCodeBean();
            detailCodeBean.setDivisionCodeNo("HR-02");
            detailCodeBean.setDetailCode(empCode);
            detailCodeBean.setDetailCodeName(empName);
            detailCodeDAO.insertDetailCode(detailCodeBean);
        } catch (Exception e) {
            throw e;

        }
    }

	@Override
	public ArrayList<DepartmentBean> findDeptList() {
		// TODO Auto-generated method stub
        ArrayList<DepartmentBean> deptList = null;
        try {
        	deptList = departmentDAO.selectDeptList();
        } catch (DataAccessException e) {
            throw e;
        }
        return deptList;
	}

	@Override
	public ArrayList<DepartmentBean> findDetailDeptList(String workplaceCode) {
		// TODO Auto-generated method stub
        ArrayList<DepartmentBean> detailDeptList = null;
        try {
        	detailDeptList = departmentDAO.selectDetailDeptList(workplaceCode);
        } catch (DataAccessException e) {
            throw e;
        }
        return detailDeptList;
	}

	@Override
	public ArrayList<DepartmentBean> findDeptList2() {
		// TODO Auto-generated method stub
        ArrayList<DepartmentBean> deptList = null;
        try {
        	deptList = departmentDAO.selectDeptList2();
        } catch (DataAccessException e) {
            throw e;
        }
        return deptList;
	}
}
